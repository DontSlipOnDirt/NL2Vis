"""Core package for nvAgent."""
